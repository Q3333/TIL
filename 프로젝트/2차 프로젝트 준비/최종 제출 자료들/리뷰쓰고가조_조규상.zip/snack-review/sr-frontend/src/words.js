export default [
  {
    text: "happy",
    value: 22
  },
  {
    text: "feel",
    value: 49
  },
  {
    text: "glasse",
    value: 19
  },
  {
    text: "vision",
    value: 12
  },
  {
    text: "pressure",
    value: 16
  },
  {
    text: "find",
    value: 29
  },
  {
    text: "experience",
    value: 59
  },
  {
    text: "year",
    value: 70
  },
  {
    text: "massage",
    value: 35
  },
  {
    text: "best",
    value: 54
  },
  {
    text: "mouth",
    value: 20
  },
  {
    text: "staff",
    value: 64
  },
  {
    text: "gum",
    value: 10
  },
  {
    text: "chair",
    value: 12
  },
  {
    text: "ray",
    value: 22
  },
  {
    text: "dentistry",
    value: 11
  },
  {
    text: "canal",
    value: 13
  },
  {
    text: "procedure",
    value: 32
  },
  {
    text: "filling",
    value: 26
  },
  {
    text: "gentle",
    value: 19
  },
  {
    text: "cavity",
    value: 17
  },
  {
    text: "crown",
    value: 14
  },
  {
    text: "cleaning",
    value: 38
  },
  {
    text: "hygienist",
    value: 24
  },
  {
    text: "dental",
    value: 59
  },
  {
    text: "charge",
    value: 24
  },
  {
    text: "cost",
    value: 29
  },
  {
    text: "charged",
    value: 13
  },
  {
    text: "spent",
    value: 17
  },
  {
    text: "paying",
    value: 14
  },
  {
    text: "pocket",
    value: 12
  },
  {
    text: "dollar",
    value: 11
  },
  {
    text: "business",
    value: 32
  },
  {
    text: "refund",
    value: 10
  }
];
