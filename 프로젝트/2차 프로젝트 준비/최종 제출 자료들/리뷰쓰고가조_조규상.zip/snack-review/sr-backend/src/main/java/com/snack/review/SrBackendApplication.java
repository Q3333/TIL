package com.snack.review;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SrBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(SrBackendApplication.class, args);
	}

}
